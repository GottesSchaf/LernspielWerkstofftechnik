﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI : MonoBehaviour {

    public Transform RadialMenue;
    public Transform MainMenue;
    public Transform Inventory;
    public Transform Album;
    public Transform Map;
    public Transform CloseupBack;
    public Transform InventoryCollision;
    public Transform MachineWindow;
    public Text zieltemp;               //Textfeld für die Zieltemperatur
    public InputField inputZieltemp;    //Das Eingabefeld für die Zieltemperatur
    bool inputZieltempBool = false;     //Boolean für Überprüfung ob das Zieltemperatur Eingabefeld ausgewählt ist
    public InputField inputRateTemp;    //Eingabefeld für die Rate in °C/h
    public Text rateTemp;               //Textfeld für die Rate in °C/h
    bool inputRateBool = false;         //Boolean für Überprüfung ob das Rate °C/h Eingabefeld ausgewählt ist
    float laufzeitSek, laufzeitMin, LaufzeitStu;    //Speicher für die Laufzeit des Ofens in Sekunden, Minuten und Stunden
    public Text laufzeitText;           //Ausgabe Textfeld für die aktuelle Laufzeit
    public Text aktuelleTempText;       //Ausgabe Textfeld für die aktuelle Temperatur
    bool laufzeitBool = false;          //Boolean zum überprüfen ob der Ofen auch anlaufen kann
    float aktuelleTemp, zielTempSpeicher, dauerSpeicher;       //Speicher für die aktuelle, zu erreichende und Rate (°C/h) Temperatur
    bool canStart = false, waiting = false;              //Boolean zur Überprüfung ob der Ofen gestartet werden kann
    float[,] funktionen = new float[1,3];                //Array zum abspeichern von den Funktionen (maximal 8), [X,0] Dauer // [X,1] StartTemperatur // [X,2] ZielTemperatur
    int arrayPosX, arrayPosY;           //Aktuelle Position im Array

    public void Start()
    {
        SetStartTemperatur();
    }

    public void Update()
    {
        InputFieldUpdate();
        //Nur wenn der Ofen die richtigen Einstellungen hat, kann dieser gestartet werden
        if (laufzeitBool)
        {
            Laufzeit_Ofen();
            StartCoroutine(TemperaturRechner());
        }
    }

    #region UI Buttons
    public void Button_OpenMenue()
    {
        Debug.Log("The MenueButton was clicked.");

        if (RadialMenue.gameObject.activeInHierarchy == false)
        {
            RadialMenue.gameObject.SetActive(true);
        }
        else
        {
            RadialMenue.gameObject.SetActive(false);
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(false);
            Map.gameObject.SetActive(false);
        }
    }

    public void Button_Screenshot()
    {
        Debug.Log("A screenshot was taken.");
    }

    public void Button_MainMenue()
    {
        Debug.Log("The MainMenueButton was clicked.");

        if (MainMenue.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(true);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(false);
        }
        else
        {
            MainMenue.gameObject.SetActive(false);
        }
    }

    public void Button_Inventory()
    {
        Debug.Log("The InventoryButton was clicked.");

        if (Inventory.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(true);
            Album.gameObject.SetActive(false);
            InventoryCollision.gameObject.SetActive(true);
        }
        else
        {
            Inventory.gameObject.SetActive(false);
            InventoryCollision.gameObject.SetActive(false);
        }
    }

    public void Button_Album()
    {
        Debug.Log("The AlbumButton was clicked.");

        if (Album.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(true);
        }
        else
        {
            Album.gameObject.SetActive(false);
        }
    }

    public void Button_Map()
    {
        Debug.Log("The MapButton was clicked.");
        Map.gameObject.SetActive(true);
    }

    public void Button_CloseMap()
    {
        Debug.Log("The Map was closed.");
        Map.gameObject.SetActive(false);
    }

    public void Button_Closeup()
    {
        Debug.Log("The Closeup was closed.");

        if (CameraFollow.instance.closeupInteraction == true)
        {
            CloseupBack.gameObject.SetActive(false);
            MachineWindow.gameObject.SetActive(false);
            CameraFollow.instance.closeupInteraction = false;
            CameraFollow.instance.playerToFollow.GetComponent<MeshRenderer>().enabled = true;
			CameraFollow.instance.playerToFollow.Find("clothes_green").GetComponent<MeshRenderer>().enabled = true;
            Book.instance.GetComponent<BoxCollider>().enabled = false;
        }
    }

    public void InputFieldUpdate()
    {
        if(inputZieltemp.isFocused == true)
        {
            inputZieltempBool = true;
            inputRateBool = false;
        }
        else if (inputRateTemp.isFocused == true)
        {
            inputZieltempBool = false;
            inputRateBool = true;
        }
    }
    #endregion

    #region Numpad
    //Numpad Button 1 fügt, je nach ausgewähltem Eingabefeld, eine 1 der Zahl hinzu. Gleiches gilt für Numapad 2 - 0
    public void Button_Numpad1()
    {
        if(inputZieltempBool)
        {
            inputZieltemp.text += "1";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "1";
        }
    }

	public void Button_Numpad2()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "2";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "2";
        }
    }

	public void Button_Numpad3()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "3";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "3";
        }
    }

	public void Button_Numpad4()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "4";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "4";
        }
    }

	public void Button_Numpad5()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "5";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "5";
        }
    }

	public void Button_Numpad6()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "6";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "6";
        }
    }

    public void Button_Numpad7()
    {
        if (inputZieltempBool)
        {
            inputZieltemp.text += "7";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "7";
        }
    }

	public void Button_Numpad8()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "8";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "8";
        }
    }

	public void Button_Numpad9()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "9";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "9";
        }
    }

	public void Button_Numpad0()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text += "0";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text += "0";
        }
    }
    //Resettet das ausgewählte Eingabefeld
	public void Button_NumpadC()
	{
        if (inputZieltempBool)
        {
            inputZieltemp.text = "";
        }
        else if (inputRateBool)
        {
            inputRateTemp.text = "";
        }
    }
    //Übergibt die eingegebenen Zahlen an die Schmelze
	public void Button_NumpadOK()
	{
        if(inputZieltemp.text != "" && inputRateTemp.text != "")
        {
            if(float.TryParse(inputZieltemp.text, out zielTempSpeicher) && float.TryParse(inputRateTemp.text, out dauerSpeicher))
            {
                //GUI.Box(new Rect(0, 0, Screen.width / 2, Screen.height / 2), "Daten erfolgreich übergeben");
                zielTempSpeicher = float.Parse(inputZieltemp.text);
                dauerSpeicher = float.Parse(inputRateTemp.text);
                canStart = true;
            }
            else
            {
                //GUI.Box(new Rect(0, 0, Screen.width / 2, Screen.height / 2), "Falsche Eingabe im Eingabefeld!");
            }
        }
        else
        {
        }
    }

    public void Button_Start()
    {
        if (canStart)
        {
            //GUI.Box(new Rect(0, 0, Screen.width / 2, Screen.height / 2), "Ofen wurde gestartet");
            laufzeitBool = true;
            canStart = false;
        }
        else
        {
            //GUI.Box(new Rect(0, 0, Screen.width / 2, Screen.height / 2), "Ofen kann aktuell nicht gestartet werden!");
        }
    }
    #endregion

    public void Laufzeit_Ofen()
    {
        laufzeitSek += Time.deltaTime;
        if(laufzeitSek >= 60f)
        {
            laufzeitMin++;
            laufzeitSek = 0;
        }
        if(laufzeitMin >= 60f)
        {
            LaufzeitStu++;
            laufzeitMin = 0;
        }
        laufzeitText.text = "Laufzeit: " + LaufzeitStu + ":" + laufzeitMin + ":" + Mathf.Round(laufzeitSek);
    }

    public IEnumerator TemperaturRechner()
    {

        if (aktuelleTemp <= zielTempSpeicher && waiting == false)
        {
            waiting = true;
            yield return new WaitForSeconds(1);
            aktuelleTemp += dauerSpeicher / 3600;    //Errechne die sekündliche Steigerungsrate der Temperatur und addiere sie zur aktuellen Temperatur hinzu
            aktuelleTempText.text = "Aktuelle Temp.: " + Mathf.Round(aktuelleTemp) + "°C";
            waiting = false;
        }
    }

    public void Button_AddFunction()
    {
        if(inputZieltemp.text != "" && inputRateTemp.text != "" && arrayPosX <= 8)
        {
            if(float.TryParse(inputZieltemp.text, out zielTempSpeicher) && float.TryParse(inputRateTemp.text, out dauerSpeicher))
            {
                zielTempSpeicher = float.Parse(inputZieltemp.text);
                dauerSpeicher = float.Parse(inputRateTemp.text);
                if (arrayPosX == 0)
                {
                    funktionen[arrayPosX, 0] = dauerSpeicher;
                    funktionen[arrayPosX, 2] = zielTempSpeicher;
                }
                else
                {
                    funktionen[arrayPosX, 0] = dauerSpeicher;
                    funktionen[arrayPosX, 1] = funktionen[arrayPosX - 1, 2];
                    funktionen[arrayPosX, 2] = zielTempSpeicher;
                }
            }
            arrayPosX++;
        }
    }

    public void Button_ResetFunction()
    {
        funktionen = new float[1,8];
        SetStartTemperatur();
    }

    public void SetStartTemperatur()
    {
        funktionen[0, 0] = 0;
        funktionen[0, 1] = 25;
        funktionen[0, 2] = 0;
        for(int i = 1; i < 9; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                funktionen[i, j] = 0;
            }
        }
    }
}
