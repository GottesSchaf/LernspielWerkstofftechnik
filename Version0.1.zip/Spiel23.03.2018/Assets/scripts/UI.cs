﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI : MonoBehaviour {

    public Transform RadialMenue;
    public Transform MainMenue;
    public Transform Inventory;
    public Transform Album;
    public Transform Map;
    public Transform CloseupBack;
    public Transform InventoryCollision;
    public Transform MachineWindow;

    public void Button_OpenMenue()
    {
        Debug.Log("The MenueButton was clicked.");

        if (RadialMenue.gameObject.activeInHierarchy == false)
        {
            RadialMenue.gameObject.SetActive(true);
        }
        else
        {
            RadialMenue.gameObject.SetActive(false);
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(false);
            Map.gameObject.SetActive(false);
        }
    }

    public void Button_Screenshot()
    {
        Debug.Log("A screenshot was taken.");
    }

    public void Button_MainMenue()
    {
        Debug.Log("The MainMenueButton was clicked.");

        if (MainMenue.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(true);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(false);
        }
        else
        {
            MainMenue.gameObject.SetActive(false);
        }
    }

    public void Button_Inventory()
    {
        Debug.Log("The InventoryButton was clicked.");

        if (Inventory.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(true);
            Album.gameObject.SetActive(false);
            InventoryCollision.gameObject.SetActive(true);
        }
        else
        {
            Inventory.gameObject.SetActive(false);
            InventoryCollision.gameObject.SetActive(false);
        }
    }

    public void Button_Album()
    {
        Debug.Log("The AlbumButton was clicked.");

        if (Album.gameObject.activeInHierarchy == false)
        {
            MainMenue.gameObject.SetActive(false);
            Inventory.gameObject.SetActive(false);
            Album.gameObject.SetActive(true);
        }
        else
        {
            Album.gameObject.SetActive(false);
        }
    }

    public void Button_Map()
    {
        Debug.Log("The MapButton was clicked.");
        Map.gameObject.SetActive(true);
    }

    public void Button_CloseMap()
    {
        Debug.Log("The Map was closed.");
        Map.gameObject.SetActive(false);
    }

    public void Button_Closeup()
    {
        Debug.Log("The Closeup was closed.");

        if (CameraFollow.instance.closeupInteraction == true)
        {
            CloseupBack.gameObject.SetActive(false);
            MachineWindow.gameObject.SetActive(false);
            CameraFollow.instance.closeupInteraction = false;
            CameraFollow.instance.playerToFollow.GetComponent<MeshRenderer>().enabled = true;
			CameraFollow.instance.playerToFollow.Find("clothes_green").GetComponent<MeshRenderer>().enabled = true;
            Book.instance.GetComponent<BoxCollider>().enabled = false;
        }
    }

    public void Button_TempUppointoone()
    {
        GameObject.Find("Temperature").GetComponent<Temperature>().value += 0.01;
    }

	public void Button_TempUppointone()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value += 0.1;
	}

	public void Button_TempUpone()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value += 1;
	}

	public void Button_TempUpten()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value += 10;
	}

	public void Button_TempUphundred()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value += 100;
	}

	public void Button_TempUpthousand()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value += 1000;
	}

    public void Button_TempDownpointoone()
    {
        GameObject.Find("Temperature").GetComponent<Temperature>().value -= 0.01;
    }

	public void Button_TempDownpointone()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value -= 0.1;
	}

	public void Button_TempDownone()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value -= 1;
	}

	public void Button_TempDownten()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value -= 10;
	}

	public void Button_TempDownhundred()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value -= 100;
	}

	public void Button_TemptDownhounsand()
	{
		GameObject.Find("Temperature").GetComponent<Temperature>().value -= 1000;
	}
}
