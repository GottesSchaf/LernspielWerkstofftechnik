﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clothes : MonoBehaviour 
{
	public GameObject inventoryobject;
	public GameObject placeholder;
}
